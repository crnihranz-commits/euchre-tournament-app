# Euchre Tournament Web App

Upload to GitHub → Deploy to Vercel.